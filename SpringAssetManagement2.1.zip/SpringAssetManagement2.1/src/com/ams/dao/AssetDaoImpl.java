package com.ams.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.ams.bean.Asset;
import com.ams.bean.Request;
import com.ams.bean.UserMaster;


@Repository
@Transactional
public class AssetDaoImpl implements IAssetDao {

	@PersistenceContext
	EntityManager entity=null;

	/***************AdminModule**************************/
	@Override
	public int addAsset(Asset asset) {
		
		entity.persist(asset);
		return asset.getAssetId();
	}
	
	@Override
	public ArrayList<Asset> getAssetList() {
		Query qry=entity.createQuery("select a from Asset a");
		return (ArrayList<Asset>)qry.getResultList();
	}

	@Override
	public Asset getAssetDetail(int assetId) {
		
		/*String qStr = "SELECT a FROM Asset a WHERE a.assetId=:assetId"; 
		TypedQuery<Asset> query = entity.createQuery(qStr,Asset.class); 
		query.setParameter("assetId", assetId);*/
		
		Asset asset=null;
		asset=entity.find(Asset.class, assetId);
		return asset;
	}
	
	@Override
	public ArrayList<Request> getList() {
		Query qry=entity.createQuery("select s from Request s");
		return (ArrayList<Request>)qry.getResultList();
	}
	
	@Override
	public int updateAsset(Asset asset) {
		/*Query query=entity.("update a Asset a")*/
		Asset assets=(Asset)entity.merge(asset);
		if(assets==null)
		{
			return 0;
		}
		else
		{
			return 1;
		}
	}
	
	@Override
	public void allocateRequest(int requestId, int quantity, int assetId) {
		//System.out.println(quantity);
		Asset asset=null;
		asset=entity.find(Asset.class, assetId);
		if(asset.getAssetQuantity()>0)
		{
			int assetQuantity = asset.getAssetQuantity()- quantity;
			//System.out.println("new quantity"+assetQuantity);
			asset.setAssetQuantity(assetQuantity);
			Query qry=entity.createQuery("update Asset set assetquantity=:assetQuantity where assetid=:assetId");
			qry.setParameter("assetQuantity", assetQuantity);
			qry.setParameter("assetId", assetId);
			int status=qry.executeUpdate();
		}
		System.out.println(asset);
		
	}
	/********************ManagerModule************************/
	
	@Override
	public int raiseRequest(Request request) {
		
		entity.persist(request);
		return request.getRequestId();
	}

	
	/********************LoginModule*************************/
	@Override
	public UserMaster login(UserMaster user) {
		try{
			
			String uname=user.getUserName();
			String pass=user.getPassword();
			System.out.println(user.getPassword());
			String qStr = "SELECT u FROM UserMaster u WHERE u.userName=:uname and u.password=:pass"; 
			TypedQuery<UserMaster> query = entity.createQuery(qStr,UserMaster.class); 
			query.setParameter("uname", uname);
			query.setParameter("pass", pass);
			UserMaster users=null;
			
			users = query.getSingleResult();  
			return users;
		}
		catch(Exception e)
		{
			return null;
		}
		
	}
	
}
