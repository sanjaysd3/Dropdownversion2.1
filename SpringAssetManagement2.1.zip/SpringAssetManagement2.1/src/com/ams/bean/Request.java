package com.ams.bean;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="request")
public class Request {

	@Id
	@GeneratedValue
	private int requestId;
	private String assetName;
	private int quantity;
	private String status;
	private String openDate;
	private String closeDate;
	private int empId;
	private int assetId;
	
	public Request() {
		
	}

	public Request(int requestId, String assetName, int quantity,
			String status, String openDate, String closeDate, int empId,
			int assetId) {
		super();
		this.requestId = requestId;
		this.assetName = assetName;
		this.quantity = quantity;
		this.status = status;
		this.openDate = openDate;
		this.closeDate = closeDate;
		this.empId = empId;
		this.assetId = assetId;
	}

	public Request(String assetName, int quantity, String status,
			String openDate, String closeDate, int empId, int assetId) {
		super();
		this.assetName = assetName;
		this.quantity = quantity;
		this.status = status;
		this.openDate = openDate;
		this.closeDate = closeDate;
		this.empId = empId;
		this.assetId = assetId;
	}

	public int getRequestId() {
		return requestId;
	}

	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}

	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getOpenDate() {
		return openDate;
	}

	public void setOpenDate(String openDate) {
		this.openDate = openDate;
	}

	public String getCloseDate() {
		return closeDate;
	}

	public void setCloseDate(String closeDate) {
		this.closeDate = closeDate;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public int getAssetId() {
		return assetId;
	}

	public void setAssetId(int assetId) {
		this.assetId = assetId;
	}

	@Override
	public String toString() {
		return "Request [requestId=" + requestId + ", assetName=" + assetName
				+ ", quantity=" + quantity + ", status=" + status
				+ ", openDate=" + openDate + ", closeDate=" + closeDate
				+ ", empId=" + empId + ", assetId=" + assetId + "]";
	}
	
	
}
