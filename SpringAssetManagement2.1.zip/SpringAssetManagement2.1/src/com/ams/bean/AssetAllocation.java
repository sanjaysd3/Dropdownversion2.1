package com.ams.bean;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="assetallocation")
public class AssetAllocation {

		@Id
		@GeneratedValue
		private int allocationId;
		private String allocationDate;
		private String releaseDate;
		private int assetId;
		private int employeeId;

		public AssetAllocation() {
			// TODO Auto-generated constructor stub
		}
		
		public AssetAllocation(int allocationId, String allocationDate,
				String releaseDate, int assetId, int employeeId) {
			super();
			this.allocationId = allocationId;
			this.allocationDate = allocationDate;
			this.releaseDate = releaseDate;
			this.assetId = assetId;
			this.employeeId = employeeId;
		}
		
		

		public AssetAllocation(String allocationDate, String releaseDate,
				int assetId, int employeeId) {
			super();
			this.allocationDate = allocationDate;
			this.releaseDate = releaseDate;
			this.assetId = assetId;
			this.employeeId = employeeId;
		}

		public int getAllocationId() {
			return allocationId;
		}

		public void setAllocationId(int allocationId) {
			this.allocationId = allocationId;
		}

		
		public String getAllocationDate() {
			return allocationDate;
		}

		public void setAllocationDate(String allocationDate) {
			this.allocationDate = allocationDate;
		}

		public String getReleaseDate() {
			return releaseDate;
		}

		public void setReleaseDate(String releaseDate) {
			this.releaseDate = releaseDate;
		}

		public int getAssetId() {
			return assetId;
		}

		public void setAssetId(int assetId) {
			this.assetId = assetId;
		}

		public int getEmployeeId() {
			return employeeId;
		}

		public void setEmployeeId(int employeeId) {
			this.employeeId = employeeId;
		}

		@Override
		public String toString() {
			return "AssetAllocation [allocationId=" + allocationId
					+ ", allocationDate=" + allocationDate + ", releaseDate="
					+ releaseDate + ", assetId=" + assetId + ", employeeId="
					+ employeeId + "]";
		}

		
}
